import matematica

print(f"Adição: {matematica.adicao(2, 5)}")
print(f"Subtração: {matematica.subtracao(2, 5)}")
print(f"Multiplicação: {matematica.multiplicacao(2, 5)}")
print(f"Divisão: {matematica.divisao(2, 5)}")