from matematica import subtracao, multiplicacao

print(f'Subtração: {subtracao(5, 2)}')
print(f'Multiplicação: {multiplicacao(5, 2)}')
