import math
import random
print (f"")