for numero in range(1, 11):
    if numero == 3:
        continue
    

    if numero == 8:
        break
    print(numero)
