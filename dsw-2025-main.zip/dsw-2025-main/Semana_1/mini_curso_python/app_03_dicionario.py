pessoa = {
    "nome": "Matheus",
    "idade":32,
    "Cidade":"Jaraguá do Sul"
}
print(f"Nome: {pessoa["nome"]}")

pessoa['profissao'] = 'Engenhero de software automobilistico'

print(pessoa)