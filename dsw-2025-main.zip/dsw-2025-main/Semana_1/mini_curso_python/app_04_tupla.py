coordenadas = (25.9, 34.6)
print(coordenadas[1])
print(coordenadas[0])
#coordenadas[1] = 55.8 "Não é possivel alterar um determinado item da tupla"
