#numero_secreto = 9
#palpite = 0
#while palpite != numero_secreto:
#    palpite = int(input("Digite um numero de 0 a 9: "))

#print("Parabens voce acertou caralho")

numero = 1
while numero <= 10:
    print(numero)
    #numero = numero +1
    numero += 1
